import java.util.Scanner;
//import java.io.*;
class inst{
	public static void main(String args[]){
		StringBuffer sb = new StringBuffer("I  Java");
		sb.insert(2, "Love ");
		System.out.println("After Insert: "+sb);
	}
}