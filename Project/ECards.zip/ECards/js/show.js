$('#hide').click(function(){
			$('#content').show('blind');
});